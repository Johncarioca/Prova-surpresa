
import { useEffect, useState } from 'react'
import './index.scss'

import situacaoAluno from '../../services/situacaoAluno';


export default function SituacaoAluno() {
    const [n1, setN1] = useState(0);
    const [n2, setN2] = useState(0);
    const [n3, setN3] = useState(0);

    const [media, setMedia] = useState(0);
    const [resul, setResul] = useState('---');



    function calcularMedia() {
        let m = (n1 + n2 + n3) / 3;
        setMedia(m);
    }


    function verificarSituacao() {
        let sit = situacaoAluno(media);
        setResul(sit);
    }


    useEffect(() => {
        // código
        calcularMedia();

    }, [n1, n2, n3])


    useEffect(() => {
        // código do efeito
        verificarSituacao();

    }, [media])


    useEffect(() => {
        // código
        setResul('<Situação do Aluno>');

    }, [])


    return (
        <section className='page-sit-aluno'>
            <h1> Situação do Aluno </h1>

            <div className='notas'>
                <div>
                    Nota 1: <input type="number" value={n1} onChange={e => setN1(Number(e.target.value))} />
                </div>
                <div>
                    Nota 2: <input type="number" value={n2} onChange={e => setN2(Number(e.target.value))} />
                </div>
                <div>
                    Nota 3: <input type="number" value={n3} onChange={e => setN3(Number(e.target.value))} />
                </div>
            </div>
            <div>
                Média: <input type="number" value={media} onChange={e => setMedia(Number(e.target.value))} />
            </div>
            <div>
                {resul}
            </div>
            {/* <button onClick={verificarSituacao}> Verificar </button> */}
        </section>
    )
}

