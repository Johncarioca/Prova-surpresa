import { useState } from 'react'
import './index.scss'


export default function Renderizacao() {
    const [mostrar, setMostrar] = useState(false);
    const [resposta, setResposta] = useState('');
    const [acertou, setAcertou] = useState(false);

    const [anime, setAnime] = useState('');


    function exibir() {
        setMostrar(true);
    }

    function ross(event) {
        if (event.target.checked) {
            setResposta('Ele só fala de dinossauros')
            setAcertou(false);
        }
    }

    function joey(event) {
        if (event.target.checked) {
            setResposta('How youuu Dooooing?')
            setAcertou(true);
        }
    }

    return (
        <section className='pagina-renderizacao'>
            <h1> Renderização </h1>
            <hr />

            <div>
                <button onClick={exibir}> Tenho uma duvidinha pra vc.. </button>

                {mostrar === true &&
                    <div>
                        <h1>Quer namorar comigo bb?</h1>
                        <img src="https://i.pinimg.com/564x/22/0b/d3/220bd39d2bf6c9b951fafec3d98d162d.jpg" alt="" />    
                    </div>
                }
            </div>
            <hr />

            <div>
                <h1> Quizzz Friends </h1>

                <h3> Qual personagem fala How youu doiiing?</h3>

                <input type="radio" name="quiz" onChange={ross} /> Ross 
                <input type="radio" name="quiz" /> Monica
                <input type="radio" name="quiz" /> Rachel
                <input type="radio" name="quiz" /> Chandler
                <input type="radio" name="quiz" /> Phoebe
                <input type="radio" name="quiz" onChange={joey} /> Joey

                {resposta === '' &&
                    <div> Aguardando resposta... </div>
                }

                {resposta !== '' &&
                    <div> {resposta} </div>
                }

                {acertou === true &&
                    <div>
                        <h2> Acertou!!!</h2>
                        <img src='https://c.tenor.com/CR1Db0YzUwwAAAAd/joey-friends.gif' alt='' />
                    </div>
                }
            </div>
            <hr />

            <div>
                <h1 className={anime}> Qual anime você assiste?</h1> 

                <span onClick={e => setAnime('DragonBall')} > Dragon Ball </span> &nbsp;
                <span onClick={e => setAnime('Naruto')}> Naruto </span> &nbsp;
                <span onClick={e => setAnime('OnePiece')}> One Piece </span> &nbsp;

                {anime === 'DragonBall' &&
                    <p> Anime super legal de demais</p> 
                }

                {anime === 'Naruto' &&
                    <p> Anime super chato de feio</p> 
                }

                {anime === 'OnePiece' &&
                    <p> Anime q n conheco...</p> 
                }
                
            </div>

        </section>
    )
}