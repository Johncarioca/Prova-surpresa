import './index.scss'

import Contador from '../../components/contador'
import Calculadora from '../../components/calculadora'

export default function VarEstado() {


    return (
        <section className='page-var-estado'>
            <h1> Variável de Estado </h1> 

            <div>
                <Contador titulo="Passos" inicio={0} />
                <Contador titulo="Crushs" inicio={3} />
                <Contador titulo="Foras do Crush" inicio={10} />

                <hr />

                <Calculadora />
            </div>
        </section>
    )

}


