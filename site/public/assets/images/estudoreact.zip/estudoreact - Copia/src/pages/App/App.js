import './App.css';

import CardPessoa from '../../components/cardPessoa'


function App() {

  function clicou() {
    alert('usuário clicou!')
  }

  function mexeuMouse(event) {
    alert('usuário mexeu no mouse')
    console.log(event); 
  }

  function alterou() {
    alert('usuario alterou')
  }

  function apertouTecla(event) {
    alert('apertou tecla ' + event.key)
  }

  let nome = 'Bruno';
  let idade = 33;

  return (
    <div className="App" on>

      <header className="App-header">
        <h1 onClick={clicou} onMouseMove={mexeuMouse}>Sua conta foi hackeada</h1>
        
        <section>
          <input type="text" onChange={alterou} onKeyDown={apertouTecla} />
          <button onClick={clicou}> Clique para ser hackeado </button>
        </section>

        <h1> Componentes </h1>

        <CardPessoa nome={nome} idade={idade} tema="claro" alinhamento="box-row" avatar="/assets/images/avatar.jfif" />
        <CardPessoa nome="Maria" idade={40} tema="escuro" alinhamento="box-column" avatar="https://media-exp1.licdn.com/dms/image/C5603AQG24DEWe117CQ/profile-displayphoto-shrink_200_200/0/1574855623895?e=1665619200&v=beta&t=5ZUB_Xzs1qbFqrOMGoovwd4xQ80VXiKqawXTPcSJkrA" />
        <CardPessoa nome="Ingrid" />
        <CardPessoa nome="Junior" />
        
      </header>
      
    </div>
  );
}


export default App;
