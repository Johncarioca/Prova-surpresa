
import './index.scss'



export default function CardPessoa(props) {

    function minhaIdade() {
        if (props.idade !== undefined)
            alert('Minha idade é ' + props.idade)
        else
            alert('Não tenho idade');
    }

    function lerTema() {
        if (props.tema !== undefined)
            return props.tema;
        else
            return 'tropical';
    }


    return (
        <section className='comp-cardPessoa'>
            <div className={lerTema()}>
                <img src={props.avatar} alt="avatar" />
                Olá eu sou o {props.nome}!
                <button onClick={minhaIdade}> Minha idade </button>
            </div>
        </section>
    )
}
