
import { useState } from 'react';
import './index.scss'

export default function Contador(props) {
    const [cont, setCont] = useState(props.inicio);


    function add() {
        setCont(cont + 1)
    }

    return (
        <section className="comp-contador">
            <h1> {props.titulo} </h1> 
            <div> {cont} </div>
            <button onClick={add}> Adicionar </button>
        </section>
    )
}



