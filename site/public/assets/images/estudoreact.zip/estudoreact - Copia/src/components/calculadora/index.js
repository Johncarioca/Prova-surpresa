
import { useState } from 'react';
import './index.scss'

export default function Calculadora(props) {
    const [n1, setN1] = useState(0);
    const [n2, setN2] = useState(0);
    const [resul, setResul] = useState(0);


    function somar() {
        let x = n1 + n2;
        setResul(x);
    }

    
    return (
        <section className="comp-contador">
            <h1> Calculadora </h1> 

            <div> Número 1: <input type="number" value={n1} onChange={e => setN1( Number(e.target.value) )} /> </div>
            <div> Número 2: <input type="number" value={n2} onChange={e => setN2( Number(e.target.value) )} /> </div>
            <div> {resul} </div>
            
            <button onClick={somar}> Somar </button>
        </section>
    )
}



