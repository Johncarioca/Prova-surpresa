


export default function situacaoAluno(media) {
    let situacao = '';

    if (media < 0 || media > 10) {
        situacao =  'Média inválida!';
    }
    else if (media >= 5) {
        situacao = 'Aluno Passou ;)';
    }
    else if (media >= 3 && media < 5) {
        situacao = 'Aluno está de Recuperação';
    }
    else {
        situacao = 'Aluno já ERAS!';
    }

    return situacao;
}

