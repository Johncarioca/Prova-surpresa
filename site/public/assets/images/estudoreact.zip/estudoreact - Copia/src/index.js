import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

import App from './pages/App/App';
import VarEstado from './pages/VarEstado';
import SituacaoAluno from './pages/SituacaoAluno';
import Renderizacao from './pages/Renderizacao';
import Tarefas from './pages/Tarefas';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Tarefas />
  </React.StrictMode>
);


